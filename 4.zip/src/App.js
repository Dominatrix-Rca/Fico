import "./App.css";
import {BrowserRouter as Router, Route , Routes} from 'react-router-dom';
import Home from "./pages/home";
import Login from "./pages/login";
import Signup from "./pages/Signup";
import Menu from "./pages/Menu";
import ProfileThree from "./pages/ProfileThree";
import Order from './pages/Order';
import Homepage from "./pages/Homepage";
import Profile from "./pages/profile";
import ProfileTwo from "./pages/ProfileTwo";
function App() {
  return (
    <div>

    <Router>

      <Routes>
        <Route index element={<Homepage />} />
        <Route path="/menu" element={<Menu />} />
        <Route path="/orders" element={<Order />} />
        {/* <Route path="/client" element={<Client />} /> */}
        <Route path="/profile3" element={<ProfileThree />} />
        <Route path="/login"  element={<Login />} />
        <Route path="/signup" element={<Signup />} /> 
        <Route path="/profile" element={<Profile />} />
        <Route path="/profiletwo" element={<ProfileTwo />} />
      </Routes>
    </Router>
    </div>
    
  );
}

export default App;
