import React from 'react';
const buttons = ["Drink", "Starter", "Appetizer", "Dessert", "Main"];

function Buttons(){
    return(
        <div className=' flex  flex-row justify-evenly pl-2 space-x-2 h-1/6 mr-8 '>

        {buttons.map((btn, index) => {
            if (index === 0) {

                return <button className='bg-orange-400 rounded-xl w-24 h-10 text-center text-white ring ring-white' key={index}>{btn}</button>
            }
            else {
                return <button className='bg-white rounded-xl w-24 h-10 text-center text-black ring ring-gray-200 ' key={index}>{btn}</button>  
            }
        })}
    


</div>
    )
}

export default Buttons;