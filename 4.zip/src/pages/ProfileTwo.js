import React, { Component } from 'react'
import '../css/profiletwo.css'
import FormTwo from '../components/FormTwo'
import RestoInfo from '../components/RestoInfoTwo'

class ProfileTwo extends Component {
  render() {
    return (
      <div className='container'>
          <div className='left'>
              <RestoInfo />
          </div>
          
            <div className='right'>
                <FormTwo />
            </div>
      </div>
    )
  }
}

export default ProfileTwo