import React, { Component } from 'react'
import '../css/profile.css'
import Form from '../components/Form';
import RestoInfo from '../components/RestoInfoTwo'

class Profile extends Component {
  render() {
    return (
      <div className='container'>
          <div className='left'>
            <RestoInfo />
          </div>
          
            <div className='right'>
                <Form />
            </div>
      </div>
    )
  }
}

export default Profile