import React from 'react';
import{Link} from 'react-router-dom';
import {CgMenuOreos} from 'react-icons/cg';
import{AiOutlineApartment } from 'react-icons/ai'
import {IoIosSettings} from 'react-icons/io';
import {FaRegLightbulb} from 'react-icons/fa';
// import {FaTicketAlt} from 'react-icons/fa';
import {AiFillPieChart} from 'react-icons/ai';

function Sidebar2(){
    return(
        <div className='  w-1/6 bg-black h-screen fixed rounded-xs'>
        <p className="flex flex-row justify-start ml-4 items-center pt-12 ">
            <span className="text-orange-400 text-2xl font-bold tracking-wider">Fico-</span>
            <span className=" text-white text-2xl font-bold tracking-wider">Food</span>
        </p>
        <div className="block mt-4 pt-4">


            <div className="flex flex-row ml-4  h-4 w-3/4 my-8  justify-start space-x-6 hover:border-l-4 border-orange-300 hover:bg-black   " >
                <AiFillPieChart className='text-gray-100 opacity-25  text-xl  mt-2 ml-2 ' />

                <p className='text-gray-100 opacity-25  text-xl text-center font-sansserif font-semibold  mt-1  hover:text-white hover:opacity-70 hover:cursor-pointer '>Over view</p>

            </div>

            
            <div className="flex flex-row ml-4  h-4 w-3/4 my-8  justify-start space-x-6 hover:border-l-4 border-orange-300" >
                <FaRegLightbulb className='text-gray-100 opacity-25 text-xl mt-2 ml-2' />
                <p className="text-gray-100 opacity-25 text-xl text-center font-sansserif font-semibold  mt-1 hover:text-white hover:opacity-70 hover:cursor-pointer">Tables</p>

            </div>

            <div className="flex flex-row ml-4 h-4 w-3/4 my-8  justify-start space-x-6 hover:border-l-4 border-orange-300">
                <IoIosSettings className='text-gray-100 opacity-25 text-xl mt-2 ml-2' />
                <Link to='/orders'>
                <li className='text-gray-100 opacity-25  text-xl text-center font-sansserif font-semibold  mt-1 hover:text-white hover:opacity-70 hover:cursor-pointer list-none'>Orders</li>
                </Link>

            </div>



            <div className="flex flex-row ml-4 h-4 w-3/4 my-8  justify-start hover:border-l-4 border-orange-300 space-x-6">
                <CgMenuOreos className='text-white text-xl mt-2 ml-2' />
                <Link to='/orders'>
                <li className=" text-white text-xl text-center font-sansserif font-semibold  mt-1 hover:cursor-pointer list-none ">Menu</li>
                </Link>


            </div>

        </div>
        <div className="block mt-8 py-4">


        <div className="flex flex-row ml-4 h-4 w-3/4 my-8  justify-start space-x-6 hover:border-l-4 border-orange-300">
                <IoIosSettings className='text-gray-100 opacity-25 text-xl mt-2 ml-2' />
                <p className='text-gray-100 opacity-25  text-xl text-center font-sansserif font-semibold  mt-1 hover:text-white hover:opacity-70 hover:cursor-pointer'>Settings</p>

            </div>
            <div className="flex flex-row ml-4  h-4 w-3/4 my-8  justify-start space-x-6 hover:border-l-4 border-orange-300 hover:bg-black   " >
                <AiOutlineApartment className='text-gray-100 opacity-25  text-xl  mt-2 ml-2 ' />

                <p className='text-gray-100 opacity-25  text-xl text-center font-sansserif font-semibold  mt-1  hover:text-white hover:opacity-70 hover:cursor-pointer '>My account</p>

            </div>




        </div>
    </div>

    )
}

export default Sidebar2;