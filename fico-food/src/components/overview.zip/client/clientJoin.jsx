import Client from './client.jsx'

function ClientFun(){
    return(
        <div>
            <Client/>
        </div>
    );
}

export default ClientFun ;